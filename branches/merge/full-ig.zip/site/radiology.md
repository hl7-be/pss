# Radiology - Prescription Search Support v1.0.0

* [**Table of Contents**](toc.md)
* [**Overview of PSS services**](services.md)
* **Radiology**

## Radiology

Functional overview of data exchange with PSS system - Antimicrobiology

### PSS-1 GetIndications - request resource structure

-------

### PSS-1 GetIndications - response resource structure

-------

### PSS-3 GetRecommendation - request resource structure

-------

### PSS-3 GetRecommendation - response resource structure

